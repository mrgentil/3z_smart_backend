<footer class="footer-wrap-layout1">
    <div class="copyright">© Copyrights <a href="#">3Z Smart</a> {{ date('Y') }}. All rights reserved. Designed by <a
            href="#">Mtech Interactives</a></div>
</footer>
