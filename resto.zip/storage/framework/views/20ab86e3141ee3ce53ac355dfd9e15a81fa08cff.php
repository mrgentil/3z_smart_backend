<div class="sidebar-menu-content">
    <ul class="nav nav-sidebar-menu sidebar-toggle-view">
        <li class="nav-item">
            <a href="<?php echo e(url('/')); ?>" class="nav-link"><i class="fas fa-home"></i><span>ACCUEIL</span></a>
        </li>
        <?php if(in_array('Admin. Système', $module_array)): ?>
        <li class="nav-item sidebar-nav-item">
            <a href="#" class="nav-link"><i class="flaticon-settings"></i><span>ADMIN. SYSTEME</span></a>
            <ul class="nav sub-group-menu">
                <li class="nav-item">
                    <a href="<?php echo e(route('roles.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Config. Niveau Accès
                        </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('users.index')); ?>" class="nav-link"><i
                            class="fas fa-angle-right"></i>Config. Compte des Utilisateurs</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('categories.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Config.
                        Categorie
                        Produit</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('products.index')); ?>" class="nav-link"><i
                            class="fas fa-angle-right"></i>Config.
                            Produit &
                            Stock</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('espaces-tables.index')); ?>" class="nav-link"><i
                            class="fas fa-angle-right"></i>Config.
                            Espaces &
                            Tables
                        </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('menus.index')); ?>" class="nav-link"><i
                            class="fas fa-angle-right"></i>Config.
                            Carte/Menu
                    </a>
                </li>
                
            </ul>
        </li>
        <?php endif; ?>
        <?php if(in_array('Tableau de bord', $module_array)): ?>
        <li class="nav-item sidebar-nav-item">
            <a href="#" class="nav-link"><i class="flaticon-dashboard"></i><span>TABLEAU DE
                BORD</span></a>
            <ul class="nav sub-group-menu">
                <li class="nav-item">
                    <a href="<?php echo e(route('commandes.index')); ?>" class="nav-link"><i class="fas fa-angle-right"></i>Commandes</a>
                </li>
                <li class="nav-item">
                    <a href="" class="nav-link"><i
                            class="fas fa-angle-right"></i>Stock</a>
                </li>
            </ul>
        </li>
        <?php endif; ?>
        <?php if(in_array('Nos Analyses', $module_array)): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/')); ?>" class="nav-link"><i class="fas fa-chart-bar"></i><span>NOS ANALYSES</span></a>
        </li>
        <?php endif; ?>

    </ul>
</div>
<?php /**PATH /home/mrgentil/Documents/Devs/3z/resources/views/components/sidebar.blade.php ENDPATH**/ ?>