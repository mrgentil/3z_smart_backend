<?php $__env->startSection('title'); ?> <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | Ajout Commande <?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
    <?php echo $__env->yieldContent('description'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?>
    ('keywords') 3Z Smart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    ('meta-image')<?php echo e(asset('img/favicon.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <h3>Produit</h3>
        <ul>
            <li>
                <a href="<?php echo e(url('/')); ?>">Accueil</a>
            </li>
            <li>Ajout Commande</li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Add New Teacher Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3>Ajout Commande</h3>
                </div>
            </div>
            

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Brand</th>
                        <th>Model</th>
                        <th>Price</th>
                        <th style="text-align: center"><a href="#" class="btn btn-info addRow">+</a></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <select name="brandom[]" id="" class="form-control">
                                <option value="">Bonjour</option>
                                <option value="">Oza bien</option>
                                <option value="">?ayoki</option>
                            </select>
                        </td>
                        <td><input type="text" name="model[]" class="form-control"></td>
                        <td><input type="text" name="price[]" class="form-control"></td>
                        <td style="text-align: center"><a href="#" class="btn btn-danger">x</a></td>
                    </tr>
                </tbody>
        </table>
    </div>
    <!-- Add New Teacher Area End Here -->

</div>


<script type="text/javascript">
    $('.addRow').on('click', function(){
        addRow();
    });
    function addRow()
    {
        alert('lisoko');
    }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mrgentil/Documents/Devs/3z/resources/views/commandes/create.blade.php ENDPATH**/ ?>