<?php $__env->startSection('title'); ?> <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | Details <?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
    <?php echo $__env->yieldContent('description'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?>
    ('keywords') 3z Smart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    ('meta-image')<?php echo e(asset('img/favicon.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Sidebar Area End Here -->
 <div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <h3>Detail Utilisateur</h3>
        <ul>
            <li>
                <a href="<?php echo e(url('/')); ?>">Accueil</a>
            </li>
            <li>Detail Utilisateur <?php echo e($users->name); ?></li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Student Details Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3>A propos de <?php echo e($users->name); ?></h3>
                </div>

            </div>
            <div class="single-info-details">
                <div class="item-img">
                    <img src="<?php echo e(asset($users->lgLogo)); ?>" alt="<?php echo e($users->name); ?>">
                </div>
                <div class="item-content">
                    <div class="header-inline item-header">
                        <h3 class="text-dark-medium font-medium"><?php echo e($users->name); ?></h3>
                        <div class="header-elements">
                            <ul>
                                <li><a href="#"><i class="far fa-edit"></i></a></li>
                                <li><a href="#"><i class="fas fa-print"></i></a></li>
                                <li><a href="#"><i class="fas fa-download"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="info-table table-responsive">
                        <table class="table text-nowrap">
                            <tbody>
                                <tr>
                                    <td>Nom:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($users->name); ?></td>
                                </tr>
                                <tr>
                                    <td>Genre:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($users->gender->name); ?></td>
                                </tr>
                                <tr>
                                    <td>E-mail:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($users->email); ?></td>
                                </tr>
                                <tr>
                                    <td>Address:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($users->adress); ?></td>
                                </tr>
                                <tr>
                                    <td>Téléphone:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($users->phone); ?></td>
                                </tr>
                                <tr>
                                    <td>Role:</td>
                                    <td class="font-medium text-dark-medium"><?php echo e($users->role->name); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mrgentil/Documents/Devs/3z/resources/views/user/show.blade.php ENDPATH**/ ?>