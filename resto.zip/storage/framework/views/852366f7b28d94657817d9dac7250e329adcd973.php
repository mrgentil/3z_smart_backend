<footer class="footer-wrap-layout1">
    <div class="copyright">© Copyrights <a href="#">3Z Smart</a> <?php echo e(date('Y')); ?>. All rights reserved. Designed by <a
            href="#">Mtech Interactives</a></div>
</footer>
<?php /**PATH /home/mrgentil/Documents/Devs/3z/resources/views/partials/footer.blade.php ENDPATH**/ ?>