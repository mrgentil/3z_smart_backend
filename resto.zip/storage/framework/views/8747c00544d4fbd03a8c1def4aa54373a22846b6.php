<?php $__env->startSection('title'); ?> <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | Les Commandes <?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
    <?php echo $__env->yieldContent('description'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?>
    ('keywords') 3z Smart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    ('meta-image')<?php echo e(asset('img/favicon.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Sidebar Area End Here -->
 <div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <h3>Les Commandes</h3>
        <ul>
            <li>
                <a href="<?php echo e(url('/')); ?>">Acueil</a>
            </li>
            <li><a class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark" href="<?php echo e(route('commandes.create')); ?>"> Ajouter une commande</a></li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Teacher Table Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3>Les Commandes</h3>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table display data-table text-nowrap">
                    <thead>
                        <th>Numero Commande</th>
                        <th>Produit</th>
                        <th>Quantité</th>
                        <th>Montant Total</th>
                        <th>Nom du Serveur</th>
                        <th>Statut</th>
                        <th>Numero Client</th>
                        <th>N# Facturation</th>
                        <th>Espace</th>
                        <th>Date Commande</th>
                        <th>Actions</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item->num_commande); ?></td>

                                                <td><?php echo e($item->product->name); ?></td>
                                                <td><?php echo e($item->quantity); ?></td>
                                                <td><?php echo e($item->amount); ?></td>
                                                <td><?php echo e($item->user->name); ?></td>
                                                <td><?php echo e($item->state); ?></td>
                                                <td><?php echo e($item->phone_client); ?></td>
                                                <td><?php echo e($item->num_facture); ?></td>
                                                <td><?php echo e($item->table->name); ?></td>
                                                <td><?php echo e($item->created_at); ?></td>
                            <td>
                                <div class="d-flex">

                                        <a href="<?php echo e(route('commandes.edit',$item)); ?>" class="mr-1 shadow btn btn-primary btn-xs sharp"><i class="fa fa-edit"></i></a>


                                        <form id="<?php echo e($item->id); ?>" action="<?php echo e(route('commandes.destroy', $item)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="shadow btn btn-danger btn-xs sharp"><i class="fa fa-trash "></i></button>
                                        </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="col-md-12 col-sm-12 col-xs-12">
                            Aucune Commande trouvée
                        </li>
                    <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mrgentil/Documents/Devs/3z/resources/views/commandes/index.blade.php ENDPATH**/ ?>