<?php $__env->startSection('title'); ?> <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | Les Utilisateurs <?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
    <?php echo $__env->yieldContent('description'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?>
    ('keywords') 3z Smart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    ('meta-image')<?php echo e(asset('img/favicon.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Sidebar Area End Here -->
 <div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <h3>Accès</h3>
        <ul>
            <li>
                <a href="<?php echo e(url('/')); ?>">Acueil</a>
            </li>
            <li><a class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark" href="<?php echo e(route('users.create')); ?>"> Ajouter un utilisateur</a></li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Teacher Table Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3>Les Niveaux Accès</h3>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table display data-table text-nowrap">
                    <thead>
                        <th>Avatar</th>
                        <th>Nom</th>
                        <th>PostNom</th>
                        <th>Prénom</th>
                        <th>Adresse</th>
                        <th>Téléphone</th>
                        <th>Adresse Email</th>
                        <th>Role</th>
                        <th>Actions</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><img src="<?php echo e(asset('images/avatar/sm/' . $item->avatar)); ?>" alt="<?php echo e($item->name); ?>"></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->firstName); ?></td>
                                                <td><?php echo e($item->lastNAme); ?></td>
                                                <td><?php echo e($item->adress); ?></td>
                                                <td><?php echo e($item->phone); ?></td>
                                                <td><?php echo e($item->email); ?></td>
                                                <td><?php echo e($item->role->name); ?></td>
                            <td>
                                <div class="d-flex">

                                        <a href="<?php echo e(route('users.edit',$item)); ?>" class="mr-1 shadow btn btn-primary btn-xs sharp"><i class="fa fa-edit"></i></a>
                                        <a href="<?php echo e(route('users.show',$item)); ?>" class="mr-1 shadow btn btn-primary btn-xs sharp"><i class="fa fa-eye"></i></a>


                                        <form id="<?php echo e($item->id); ?>" action="<?php echo e(route('users.destroy', $item)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="shadow btn btn-danger btn-xs sharp"><i class="fa fa-trash "></i></button>
                                        </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="col-md-12 col-sm-12 col-xs-12">
                            Aucun Utilisateur trouvé
                        </li>
                    <?php endif; ?>

                    </tbody>
                </table>
                <div class="d-flex justify-content-center">
                    <?php echo $users->links(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mrgentil/Documents/Devs/3z/resources/views/user/index.blade.php ENDPATH**/ ?>