<form class="new-added-form" action="<?php echo e(isset($action) && $action ===  'POST' ?  route('commandes.store') :  route('commandes.update', $commande)); ?>"
enctype="multipart/form-data" method="POST">
    <div class="row">
        <?php echo csrf_field(); ?>
    <?php if(isset($action) && $action ===  'PUT'): ?>
        <input type="hidden" name="_method" value="PUT">
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
        <div class="col-xl-3 col-lg-6 col-12 form-group">
            <label>QUantité *</label>
            <input type="text" name="quantity" value="<?php echo e((old('quantity')) ? old('quantity') : ((isset($commande) ? $commande->quantity : ''))); ?>"  class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="quantity" placeholder="Quantité" required="required">
            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <div class="col-xl-3 col-lg-6 col-12 form-group">
            <label>Espace *</label>
            <select id="table_espace_id" value="<?php echo e((old('table_espace_id')) ? old('table_espace_id') : ((isset($commande) ? $commande->table_espace_id : ''))); ?>" name="table_espace_id" class="form-control select2 <?php $__errorArgs = ['table_espace_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <div class="col-xl-3 col-lg-6 col-12 form-group">
            <label>Produit *</label>
            <select id="product_id" value="<?php echo e((old('product_id')) ? old('product_id') : ((isset($commande) ? $commande->product_id : ''))); ?>" name="product_id[]" class="form-control select2 <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" multiple="multiple">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-12 form-group mg-t-8">
            <button type="submit" class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark"><?php echo e(isset($action) && $action ===  'POST' ? 'Enregistrer' : 'Modiier'); ?></button>

        </div>
    </div>
</form>
<?php /**PATH /home/mrgentil/Documents/Devs/3z/resources/views/commandes/form.blade.php ENDPATH**/ ?>