<?php $__env->startSection('title'); ?> <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | Les Produits <?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
    <?php echo $__env->yieldContent('description'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?>
    ('keywords') 3z Smart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    ('meta-image')<?php echo e(asset('img/favicon.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Sidebar Area End Here -->
 <div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <h3>Les Produits</h3>
        <ul>
            <li>
                <a href="<?php echo e(url('/')); ?>">Acueil</a>
            </li>
            <li><a class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark" href="<?php echo e(route('products.create')); ?>"> Ajouter un produit</a></li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Teacher Table Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3>Les Produits</h3>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table display data-table text-nowrap">
                    <thead>
                        <th>Nom</th>
                        <th>Categorie</th>
                        <th>Prix</th>
                        <th>Stock</th>
                        <th>Notif Min</th>
                        <th>Portion</th>
                        <th>Quantité portion</th>
                        <th>Prix portion</th>
                        <th>Actions</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>

                                                <td><?php echo e($item->categorie->name); ?></td>
                                                <td><?php echo e($item->price_product); ?></td>
                                                <td><?php echo e($item->stock); ?></td>
                                                <td><?php echo e($item->notif_min); ?></td>
                                                <td><?php echo e($item->portion); ?></td>
                                                <td><?php echo e($item->quantity_total_portion); ?></td>
                                                <td><?php echo e($item->price_portion); ?></td>
                            <td>
                                <div class="d-flex">

                                        <a href="<?php echo e(route('products.edit',$item)); ?>" class="mr-1 shadow btn btn-primary btn-xs sharp"><i class="fa fa-edit"></i></a>


                                        <form id="<?php echo e($item->id); ?>" action="<?php echo e(route('products.destroy', $item)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="shadow btn btn-danger btn-xs sharp"><i class="fa fa-trash "></i></button>
                                        </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="col-md-12 col-sm-12 col-xs-12">
                            Aucun Produit trouvé
                        </li>
                    <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mrgentil/Documents/Devs/3z/resources/views/products/index.blade.php ENDPATH**/ ?>