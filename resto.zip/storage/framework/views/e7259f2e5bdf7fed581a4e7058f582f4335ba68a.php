<?php $__env->startSection('title'); ?> <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | Details <?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
    <?php echo $__env->yieldContent('description'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?>
    ('keywords') 3z Smart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-image'); ?>
    ('meta-image')<?php echo e(asset('img/favicon.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Sidebar Area End Here -->
 <div class="dashboard-content-one">
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <h3>Detail Menu</h3>
        <ul>
            <li>
                <a href="<?php echo e(url('/')); ?>">Accueil</a>
            </li>
            <li>Detail Menu <?php echo e($carteMenu->name); ?></li>
        </ul>
    </div>
    <!-- Breadcubs Area End Here -->
    <!-- Student Details Area Start Here -->
    <div class="card height-auto">
        <div class="card-body">
            <div class="heading-layout1">
                <div class="item-title">
                    <h3>A propos de Menu : <?php echo e($carteMenu->name); ?></h3>
                </div>

            </div>
            <div class="single-info-details">
                <div class="item-content">

                    <div class="info-table table-responsive">
                        <table class="table text-nowrap">
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $carteMenu->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li><?php echo e($item->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="col-md-12 col-sm-12 col-xs-12">
                                    Aucun Produit trouvé
                                </li>
                                <?php endif; ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mrgentil/Documents/Devs/3z/resources/views/menus/show.blade.php ENDPATH**/ ?>